import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { CurrencySelector } from './components/CurrencySelector';
import { ConversionResult } from './components/ConversionResult';
import { ExchangeRateChart } from './components/ExchangeRateChart';
import { TimePeriodSelector } from './components/TimePeriodSelector';
import { convertCurrency, getExchangeRate, generateHistoricalData } from './utils/currencyService';
import { TimePeriod } from './types/currency';
import { RefreshCw, ArrowLeftRight } from 'lucide-react';

function App() {
  const [amount, setAmount] = useState<number>(100);
  const [fromCurrency, setFromCurrency] = useState<string>('USD');
  const [toCurrency, setToCurrency] = useState<string>('CNY');
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('1M');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const result = convertCurrency(amount, fromCurrency, toCurrency);
  const rate = getExchangeRate(fromCurrency, toCurrency);
  const historicalData = generateHistoricalData(fromCurrency, toCurrency, selectedPeriod);
  const timestamp = new Date().toLocaleString('zh-CN');

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const handleConvert = () => {
    // 触发转换动画或其他效果
    handleRefresh();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* 货币选择区域 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
            {/* 原始货币 */}
            <div>
              <CurrencySelector
                selectedCurrency={fromCurrency}
                onCurrencyChange={setFromCurrency}
                label="原始货币："
              />
            </div>

            {/* 交换按钮 */}
            <div className="flex justify-center">
              <button
                onClick={handleSwapCurrencies}
                className="flex items-center justify-center w-12 h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full transition-colors shadow-md"
                title="交换货币"
              >
                <ArrowLeftRight className="w-5 h-5" />
              </button>
            </div>

            {/* 目标货币 */}
            <div>
              <CurrencySelector
                selectedCurrency={toCurrency}
                onCurrencyChange={setToCurrency}
                label="目标货币："
              />
            </div>
          </div>
        </div>

        {/* 兑换数额输入区域 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                兑换数额：
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full p-4 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="请输入金额"
              />
            </div>
            <button
              onClick={handleConvert}
              className="px-8 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              disabled={isLoading}
            >
              {isLoading ? '转换中...' : '兑换'}
            </button>
          </div>
        </div>

        {/* 转换结果 */}
        <div className="mb-6">
          <ConversionResult
            amount={amount}
            fromCurrency={fromCurrency}
            toCurrency={toCurrency}
            result={result}
            rate={rate}
            timestamp={timestamp}
          />
        </div>

        {/* 汇率图表 */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 space-y-4 sm:space-y-0">
            <h2 className="text-xl font-semibold text-gray-800">汇率历史走势</h2>
            <TimePeriodSelector
              selectedPeriod={selectedPeriod}
              onPeriodChange={setSelectedPeriod}
            />
          </div>

          <ExchangeRateChart
            data={historicalData}
            fromCurrency={fromCurrency}
            toCurrency={toCurrency}
          />
        </div>

        {/* 汇率变化信息 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">24小时变化</h3>
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-green-600">+0.25%</span>
              <span className="text-sm text-gray-600">较昨日</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">52周最高</h3>
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-gray-800">{(rate * 1.15).toFixed(4)}</span>
              <span className="text-sm text-gray-600">{fromCurrency}/{toCurrency}</span>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">52周最低</h3>
            <div className="flex items-center space-x-2">
              <span className="text-2xl font-bold text-gray-800">{(rate * 0.85).toFixed(4)}</span>
              <span className="text-sm text-gray-600">{fromCurrency}/{toCurrency}</span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;