import React from 'react';
import { currencies } from '../data/currencies';

interface ConversionResultProps {
  amount: number;
  fromCurrency: string;
  toCurrency: string;
  result: number;
  rate: number;
  timestamp: string;
}

export const ConversionResult: React.FC<ConversionResultProps> = ({
  amount,
  fromCurrency,
  toCurrency,
  result,
  rate,
  timestamp,
}) => {
  const fromCurrencyData = currencies.find(c => c.code === fromCurrency);
  const toCurrencyData = currencies.find(c => c.code === toCurrency);

  return (
    <div className="bg-white border-2 border-gray-200 rounded-xl p-8 text-center">
      <div className="flex items-center justify-center space-x-4 mb-6">
        <div className="text-right">
          <div className="text-3xl font-bold text-red-600">
            {amount.toLocaleString()} {fromCurrency}
          </div>
          <div className="text-lg text-gray-600 mt-1">{fromCurrencyData?.name}</div>
        </div>
        
        <div className="text-4xl font-bold text-gray-400">=</div>
        
        <div className="text-left">
          <div className="text-3xl font-bold text-green-600">
            {result.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 })} {toCurrency}
          </div>
          <div className="text-lg text-gray-600 mt-1">{toCurrencyData?.name}</div>
        </div>
      </div>

      <div className="text-sm text-gray-500">
        汇率更新时间：{timestamp}
      </div>
    </div>
  );
};