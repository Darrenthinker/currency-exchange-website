import { exchangeRates } from '../data/currencies';
import { ExchangeRate, TimePeriod } from '../types/currency';

export const convertCurrency = (
  amount: number,
  fromCurrency: string,
  toCurrency: string
): number => {
  if (fromCurrency === toCurrency) return amount;
  
  const rate = exchangeRates[fromCurrency]?.[toCurrency];
  if (!rate) return 0;
  
  return amount * rate;
};

export const getExchangeRate = (
  fromCurrency: string,
  toCurrency: string
): number => {
  if (fromCurrency === toCurrency) return 1;
  return exchangeRates[fromCurrency]?.[toCurrency] || 0;
};

export const generateHistoricalData = (
  fromCurrency: string,
  toCurrency: string,
  period: TimePeriod
): ExchangeRate[] => {
  const baseRate = getExchangeRate(fromCurrency, toCurrency);
  const days = getDaysForPeriod(period);
  const data: ExchangeRate[] = [];
  
  for (let i = days; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    // Generate realistic rate fluctuations
    const variation = (Math.random() - 0.5) * 0.1; // ±5% variation
    const rate = baseRate * (1 + variation);
    const change = i === 0 ? 0 : (rate - baseRate) * 100;
    const changePercent = i === 0 ? 0 : (change / baseRate) * 100;
    
    data.push({
      date: date.toISOString().split('T')[0],
      rate: Number(rate.toFixed(4)),
      change: Number(change.toFixed(4)),
      changePercent: Number(changePercent.toFixed(2)),
    });
  }
  
  return data;
};

const getDaysForPeriod = (period: TimePeriod): number => {
  switch (period) {
    case '1D': return 1;
    case '5D': return 5;
    case '1M': return 30;
    case '1Y': return 365;
    case '5Y': return 1825;
    case 'MAX': return 3650;
    default: return 30;
  }
};

export const formatCurrency = (amount: number, currency: string): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
  }).format(amount);
};

export const formatRate = (rate: number): string => {
  return rate.toFixed(4);
};